using AA.PMTOGO.DataAccess;
using AA.PMTOGO.Models;
using System.Data.SqlClient;
using System.Text;

namespace DIYUnitTest
{
    [TestClass]
    public class UnitTest1
    {
        private const string _connectionString = @"Server=localhost\SQLEXPRESS;Database=master;Trusted_Connection=True;";

        [TestMethod]
        public void TestConnection_ValidConnectionString_ReturnsTrue()
        {
            var dao = new DIYDAO();
            var result = dao.TestConnection();
            Assert.IsTrue(result);
        }
        
        [TestMethod]
        public async Task UploadInfo_NameDescriptionEmail_Success()
        {
            // Arrange
            var dao = new DIYDAO();
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            var random = new Random();
            string name = new string(Enumerable.Repeat(chars, 10).Select(s => s[random.Next(s.Length)]).ToArray());
            string description = "This is a test DIYObject";
            string email = "test@test.com";

            // Act
            var result = await dao.UploadInfo(email, name, description);

            // Assert
            Assert.IsTrue(result);
        }
        [TestMethod]
        public async Task UploadInfo_SameName_Failure()
        {
            // Arrange
            var dao = new DIYDAO();
            string name = "test";
            string description = "This is a test DIYObject";
            string email = "test@test.com";

            // Act
            await dao.UploadInfo(email, name, description);
            var result2 = await dao.UploadInfo(email, name, description);

            // Assert
            Assert.IsFalse(result2);
        }

    }

}
