﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using AA.PMTOGO.Manager;
using AA.PMTOGO.Models;

namespace AA.PMTOGO.Controllers
{
    public class HomeController : Controller
    {
        private readonly IWebHostEnvironment _hostingEnvironment;
        private readonly DIYManager _dIYManager;

        public HomeController(IWebHostEnvironment hostingEnvironment, DIYManager diyProjectManager)
        {
            _hostingEnvironment = hostingEnvironment;
            _dIYManager = diyProjectManager;
        }

        public IActionResult Index()
        {
            return Dashboard(); 
        }
        public IActionResult AddDIY()
        {
            return View("AddDIY");
        }
        public IActionResult SearchDIY()
        {
            return View("SearchDIY");
        }


        [HttpPost]
        public async Task<IActionResult> Upload(string name, string description, string email, IFormFile videoFile)
        {
            var success = await _dIYManager.UploadInfoAsync(email, name, description);

            if (success)
            {
                ViewBag.Message = "Video will start uploading shortly.";
                success = await _dIYManager.UploadVideoAsync(email, name, videoFile);
                return View("DIYDetails", _dIYManager.GetLastDIY());

            }
            else
            {
                ViewBag.Message = "Invalid Data Video will not be uploaded.";
            }

            return View("Index");
        }

        public IActionResult Dashboard()
        {
            var diyObjects = _dIYManager.GetAllDIY().Take(5).ToList();
            return View("Index", diyObjects);
        }
        public IActionResult Details(DIYObject diyObject)
        {
            return View("DIYDetails", diyObject);
        }
        public IActionResult GetVideo()
        {
            MemoryStream videoStream = _dIYManager.GetLastDIY().Video;

            return new FileStreamResult(videoStream, "video/mp4");
        }
        [HttpPost]
        public IActionResult SearchDIYs(string name)
        {
            if (string.IsNullOrEmpty(name))
            {
                return RedirectToAction("Index");
            }

            var diyList = _dIYManager.SearchDIY(name);

            ViewBag.SearchTerm = name;

            return View(diyList);
        }
    }  
}