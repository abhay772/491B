﻿using AA.PMTOGO.DataAccess;
using AA.PMTOGO.Models;
using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;

namespace AA.PMTOGO.Service
{
    public class DIYService
    {
        private readonly DIYDAO _diyDao;

        public DIYService()
        {
            _diyDao = new DIYDAO();
        }

        public async Task<bool> UploadVideo(string email, string name, IFormFile videoFile)
        {
            // Convert IFormFile to byte[]
            byte[] videoBytes;
            using (var stream = videoFile.OpenReadStream())
            {
                using (var memoryStream = new MemoryStream())
                {
                    await stream.CopyToAsync(memoryStream);
                    videoBytes = memoryStream.ToArray();
                }
            }

            return await _diyDao.UploadVideo(email, name, videoBytes);
        }
        public List<DIYObject> SearchDIY(string name)
        {
            var dao = new DIYDAO();
            var result = dao.SearchDIY(name);
            return result;
        }
    }
}