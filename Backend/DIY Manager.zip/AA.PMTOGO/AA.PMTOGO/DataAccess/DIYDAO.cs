﻿using System.Data.SqlClient;
using AA.PMTOGO.Models;

namespace AA.PMTOGO.DataAccess
{
    public class DIYDAO
    {
        private static readonly string _connectionString = @"Server=localhost\SQLEXPRESS;Database=master;Trusted_Connection=True;";

        public DIYDAO() { }

        public bool TestConnection()
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                try
                {
                    connection.Open();
                    return true;
                }
                catch (SqlException)
                {
                    return false;
                }
            }
        }
        public void CreateAndPopulateDIYTable()
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                var createTableCommand = new SqlCommand("CREATE TABLE DIYTable (DIYEmail VARCHAR(50), DIYName VARCHAR(50), DIYDescription VARCHAR(200), DIYVideo VARBINARY(MAX))", connection);
                createTableCommand.ExecuteNonQuery();

                var insertDataCommand = new SqlCommand("INSERT INTO DIYTable (DIYEmail, DIYName, DIYDescription, DIYVideo) VALUES ('example1@example.com', 'Example 1', 'This is an example DIYObject project', 0x1234567890)", connection);
                insertDataCommand.ExecuteNonQuery();

                insertDataCommand = new SqlCommand("INSERT INTO DIYTable (DIYEmail, DIYName, DIYDescription, DIYVideo) VALUES ('example2@example.com', 'Example 2', 'This is another example DIYObject project', 0x2345678901)", connection);
                insertDataCommand.ExecuteNonQuery();
            }
        }
        public async Task<bool> UploadInfo(string email, string name, string description)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();

                // Check if there's already a row with the same email and name
                var checkCommand = new SqlCommand("SELECT COUNT(*) FROM DIYTable WHERE DIYEmail = @Email AND DIYName = @Name", connection);
                checkCommand.Parameters.AddWithValue("@Email", email);
                checkCommand.Parameters.AddWithValue("@Name", name);

                var rowCount = (int)await checkCommand.ExecuteScalarAsync();

                // If there's already a row with the same email and name, return false
                if (rowCount > 0)
                {
                    return false;
                }

                // If there's no row with the same email and name, insert the new row
                var insertCommand = new SqlCommand("INSERT INTO DIYTable (DIYEmail, DIYName, DIYDescription) VALUES (@Email, @Name, @Description)", connection);
                insertCommand.Parameters.AddWithValue("@Email", email);
                insertCommand.Parameters.AddWithValue("@Name", name);
                insertCommand.Parameters.AddWithValue("@Description", description);

                var result = await insertCommand.ExecuteNonQueryAsync();

                return result > 0;
            }
        }

        public async Task<bool> UploadVideo(string email, string name, byte[] videoFile)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();

                // check if there is a row in the database with the same email and name
                var checkCommand = new SqlCommand("SELECT COUNT(*) FROM DIYTable WHERE DIYEmail=@Email AND DIYName=@Name", connection);
                checkCommand.Parameters.AddWithValue("@Email", email);
                checkCommand.Parameters.AddWithValue("@Name", name);
                var count = (int)await checkCommand.ExecuteNonQueryAsync();

                if (count > 0)
                {
                    // if row exists, update it with the video file
                    var command = new SqlCommand("UPDATE DIYTable SET DIYVideo=@Video WHERE DIYEmail=@Email AND DIYName=@Name", connection);
                    command.Parameters.AddWithValue("@Video", videoFile);
                    command.Parameters.AddWithValue("@Email", email);
                    command.Parameters.AddWithValue("@Name", name);

                    var result = await command.ExecuteNonQueryAsync();

                    return result > 0;
                }
                else
                {
                    // if row does not exist, return false
                    return false;
                }
            }
        }
        public List<DIYObject> GetAllDIYs()
        {
            var diyList = new List<DIYObject>();

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                string sqlQuery = "SELECT * FROM DIYTable";

                var command = new SqlCommand(sqlQuery, connection);

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var diy = new DIYObject
                        {
                            Email = reader["DIYEmail"].ToString(),
                            Name = reader["DIYName"].ToString(),
                            Description = reader["DIYDescription"].ToString(),
                        };

                        if (reader["DIYVideo"] != DBNull.Value)
                        {
                            diy.Video = new MemoryStream((byte[])reader["DIYVideo"]);
                        }

                        diyList.Add(diy);
                    }
                }
            }

            return diyList;
        }
        public async Task<bool> ClearDIYTable()
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();

                var command = new SqlCommand("DELETE FROM DIYTable", connection);

                var result = await command.ExecuteNonQueryAsync();

                return result > 0;
            }
        }

        public List<DIYObject> SearchDIY(string name)
        {
            var diyList = new List<DIYObject>();

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                string sqlQuery = "SELECT * FROM DIYTable WHERE DIYName LIKE '%' + @Name + '%'";

                var command = new SqlCommand(sqlQuery, connection);
                command.Parameters.AddWithValue("@Name", name);

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var diy = new DIYObject
                        {
                            Email = reader["DIYEmail"].ToString(),
                            Name = reader["DIYName"].ToString(),
                            Description = reader["DIYDescription"].ToString(),
                            Video = new MemoryStream((byte[])reader["DIYVideo"])
                        };

                        diyList.Add(diy);
                    }
                }
            }

            return diyList;
        }
    }
    
}
