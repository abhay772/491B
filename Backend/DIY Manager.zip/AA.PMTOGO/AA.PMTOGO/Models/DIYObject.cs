﻿namespace AA.PMTOGO.Models
{
    public class DIYObject
    {
        public string Email { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public MemoryStream Video { get; set; }
    }
}
