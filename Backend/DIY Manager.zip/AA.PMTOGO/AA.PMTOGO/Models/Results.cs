﻿namespace AA.PMTOGO.Models
{
    public class Result
    {
        public bool IsSuccessful { get; internal set; }
        public string ErrorMessage { get; internal set; }
    }
}
