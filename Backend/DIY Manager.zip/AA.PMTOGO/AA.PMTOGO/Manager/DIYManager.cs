﻿using System.Threading.Tasks;
using AA.PMTOGO.DataAccess;
using AA.PMTOGO.Models;
using AA.PMTOGO.Service;
using Microsoft.AspNetCore.Http;

namespace AA.PMTOGO.Manager
{
    public class DIYManager
    {
        public async Task<bool> UploadInfoAsync(string email, string name, string description)
        {
            var dao = new DIYDAO();
            var result = await dao.UploadInfo(email, name, description);
            return result;
        }

        public async Task<bool> UploadVideoAsync(string email, string name, IFormFile videoFile)
        {
            var dIYService = new DIYService();
            var result = await dIYService.UploadVideo(email, name, videoFile);
            return true;
        }

        public List<DIYObject> GetAllDIY()
        {
            var dao = new DIYDAO();
            var result = dao.GetAllDIYs();
            return result;
        }
        public List<DIYObject> SearchDIY(string name)
        {
            var dIYService = new DIYService();
            var result = dIYService.SearchDIY(name);
            return result;
        }
        public DIYObject GetLastDIY()
        {
            var dao = new DIYDAO();
            var result = dao.GetAllDIYs();
            return result.LastOrDefault();
        }

    }
}