﻿namespace AA.PMTOGO.SqlUserDAO
{
    public class Result
    {
        public bool IsSuccessful { get; internal set; }
        public string ErrorMessage { get; internal set; }
    }
}