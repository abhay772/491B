﻿namespace AA.PMTOGO.Data
{
    public class Class1
    {

    }
}